$( document ).ready(function() {
	
	var settings = {
		timeformat: "hh:mm",
		dateformat: "yyyy-MM-dd"
	};
	
	var $key = "e3aa4b8a-a8e9-4614-bb44-ecaae085f27c";
	var $timetable = $("#timetable");
	var $errorMessage = null;

	var $allDepartures = new Array();
	
	/*
	STATION/HÅLLPLATS 				SL-id		Reserobot-id
	Mörby station					9638		740020867
	Solna strand - Huvudstaleden	9328		740026077
	Solna strand					9326		740021671
	*/
	
	var $busid = "740026077";
	var $metroid = "740021671";
	var $direction = "740020867";
	
	var $maxJourneys = "5";
	var $date = new Date();
	
	console.log("https://api.resrobot.se/v2/departureBoard?key=" + $key + "&id=" + $metroid + "&maxJourneys=" + $maxJourneys + "&format=json");

	$.ajax({
		url: "https://api.resrobot.se/v2/departureBoard?key=" + $key + "&id=" + $busid + "&maxJourneys=" + $maxJourneys + "&format=json&direction=" + $direction,
		type: "GET",
		dataType: "json",
		success: function(result){
			var departures = createDepartures(result.Departure);
			storeValues(departures, false);
		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			document.write(errorThrown);
		}
	});
	
	$.ajax({
		url: "https://api.resrobot.se/v2/departureBoard?key=" + $key + "&id=" + $metroid + "&maxJourneys=" + $maxJourneys + "&format=json&products=32",
		type: "GET",
		dataType: "json",
		success: function(result){
			var departures = createDepartures(result.Departure);
			storeValues(departures, true);
		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			document.write(errorThrown);
		}
	});
	
	function storeValues(departures, done){
		
		$allDepartures = $allDepartures.concat(departures);
		
		if(done){
			printTable($allDepartures);
		}
	}
	
	function printTable(departures){
		
		if(departures && Array.isArray(departures)){
				
			if(departures.length > 1){
				departures.sort((a,b) => (a.timetable > b.timetable) ? 1 : -1);
			}
				
			for(var i=0; i<departures.length; i++){
				var stringToAppend = "<tr>\r\n";
				if(departures[i].metro){
					stringToAppend += "<td><img src='metro.svg' alt='Tunnelbana' class='metro'></td>\r\n";
				}
				else{
					stringToAppend += "<td>" + departures[i].line + "</td>\r\n";
				}
					stringToAppend += "<td>" + departures[i].stop + "</td>\r\n";
					stringToAppend += "<td>" + departures[i].destination + "</td>\r\n";
					stringToAppend += "<td>" + departures[i].timetable + "</td>\r\n";
				if(departures[i].expected){
					stringToAppend += "<td>" + departures[i].expected + "</td>\r\n";
				}
				else{
					stringToAppend += "<td></td>\r\n";
				}	
				if(departures[i].deviation){
					stringToAppend += "<td>" + departures[i].deviation + "</td>\r\n";
				}
				else{
					stringToAppend += "<td></td>\r\n";
				}
				stringToAppend += "</tr>\r\n";
				$timetable.append(stringToAppend);
			}
		}
		else{
			document.write("Error.");
		}
		
	}


	function createDepartures(departures){
		
		var result = new Array();
		
		if(departures && departures.length > 0){
			
			for(var i=0; i<departures.length; i++){
				
				var time = formatTime(departures[i].time);
				var expectedTime = formatTime(departures[i].rtTime);
				var metro = departures[i].Product.catOutS === "ULT";
				
				var departure = {
					line: departures[i].Product.num,
					destination: departures[i].direction,
					stop: departures[i].stop,
					timetable: time,
					expected: expectedTime,
					metro: metro,
					deviations: null
				};
				
				result.push(departure);					
			}
		}
		
		return result;
	}
	
	function formatTime(rawTimeValue){
		
		if(rawTimeValue){
			return rawTimeValue.substr(0,5);
		}
		else{
			return null;
		}
		
	}

});

/*https://api.sl.se/api2/typeahead.json?key=8818e298dccd493099c07562f61da899&searchstring=Mörby station&stationsonly=true&maxresults=10*/