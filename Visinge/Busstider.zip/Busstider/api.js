$( document ).ready(function() {
	
	//API-key
	var $key = "e3aa4b8a-a8e9-4614-bb44-ecaae085f27c";
	
	//Station ids
	var stations = {
		0: {
			name: "Mörby station",
			sl: 9638,
			id: 740020867
		},
		1: {
			name: "Solna strand Huvudstaleden",
			sl: 9328,
			id: 740026077
		},
		2: {
			name: "Solna strand",
			sl: 9326,
			id: 740021671
		}
	};
	
	//Settings
	var settings = {
		timeformat: "hh:mm",
		dateformat: "yyyy-MM-dd",
		maxJourneys: 8
	};
	
	//Departure list
	var $allDepartures = new Array();
	
	//Table to append results to
	var $timetable = $("#timetable");

	//Set stations for query
	var $busid = stations[1].id;
	var $metroid = stations[2].id;
	var $direction = stations[0].id;
	
	//Bus request
	$.ajax({
		url: "https://api.resrobot.se/v2/departureBoard?key=" + $key + "&id=" + $busid + "&maxJourneys=" + settings.maxJourneys + "&format=json&direction=" + $direction,
		type: "GET",
		dataType: "json",
		success: function(result){
			
			//Create departure objects from results
			var departures = createDepartures(result.Departure);
			
			//Store objects in global list
			storeValues(departures);
		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			document.write(errorThrown);
		}
	});
	
	//Metro request
	$.ajax({
		url: "https://api.resrobot.se/v2/departureBoard?key=" + $key + "&id=" + $metroid + "&maxJourneys=" + settings.maxJourneys + "&format=json&products=32",
		type: "GET",
		dataType: "json",
		success: function(result){
			
			//Create departure objects from results
			var departures = createDepartures(result.Departure);
			
			//Store objects in global list
			storeValues(departures);
		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			document.write(errorThrown);
		}
	});
	
	//Store request results
	function storeValues(departures){
		
		var done = false;
		
		//Check if request has been done previously.
		if($allDepartures.length > 0){
			done = true;
		}
		
		//Combine new and previous results
		$allDepartures = $allDepartures.concat(departures);
		
		//Print results if both requests are done
		if(done){
			printTable($allDepartures);
		}
	}
	
	//Add departures to table
	function printTable(departures){
		
		if(departures && Array.isArray(departures)){
			
			//Sort by time of departure
			if(departures.length > 1){
				departures.sort((a,b) => (a.timetable > b.timetable) ? 1 : -1);
			}
				
			//Create html string
			for(var i=0; i<departures.length; i++){
				var stringToAppend = "<tr>\r\n";
				if(departures[i].metro){
					stringToAppend += "<td class='metro'><img src='metro.png' alt='Tunnelbana' class='metrosign'></td>\r\n";
				}
				else{
					stringToAppend += "<td class='number'>" + departures[i].line + "</td>\r\n";
				}
					stringToAppend += "<td>" + departures[i].stop + "</td>\r\n";
					stringToAppend += "<td>" + departures[i].destination + "</td>\r\n";
					stringToAppend += "<td class='number'>" + departures[i].timetable + "</td>\r\n";
				if(departures[i].expected){
					stringToAppend += "<td class='number'>" + departures[i].expected + "</td>\r\n";
				}
				else{
					stringToAppend += "<td></td>\r\n";
				}	
				if(departures[i].deviation){
					stringToAppend += "<td>" + departures[i].deviation + "</td>\r\n";
				}
				else{
					stringToAppend += "<td></td>\r\n";
				}
				stringToAppend += "</tr>\r\n";
				
				//Append html string
				$timetable.append(stringToAppend);
			}
		}
		else{
			document.write("Error.");
		}
		
	}

	//Create departure objects
	function createDepartures(departures){
		
		//Result list
		var result = new Array();
		
		//If any departures in list
		if(departures && departures.length > 0){
			
			//Create objects of all departures
			for(var i=0; i<departures.length; i++){
				
				//Time of departure
				var time = formatTime(departures[i].time);
				
				//Real time
				var expectedTime = formatTime(departures[i].rtTime);
				
				//Departure of metro
				var metro = departures[i].Product.catOutS === "ULT";
				
				//Name of destination
				var destination = formatDestination(departures[i].direction);
				
				//Start of journey
				var stop = formatDestination(departures[i].stop);
				
				//Departure object
				var departure = {
					line: departures[i].Product.num,
					destination: destination,
					stop: stop,
					timetable: time,
					expected: expectedTime,
					metro: metro,
					deviations: null
				};
				
				//Add departure object to array
				result.push(departure);					
			}
		}
		
		return result;
	}
	
	//Format destination name
	function formatDestination(destination){
		return destination.replace('T-bana','').trim();
	}
	
	//Format time
	function formatTime(rawTimeValue){
		
		if(rawTimeValue){
			return rawTimeValue.substr(0,5);
		}
		else{
			return null;
		}
		
	}

});