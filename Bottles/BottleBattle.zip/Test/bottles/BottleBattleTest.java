package bottles;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

class BottleBattleTest {

    BottleBattle bottleBattle = new BottleBattle();

    @Test
    void createEmptyStates() {

        State emptyStateRunOne = bottleBattle.createEmptyState(true);
        State emptyStateRunTwo = bottleBattle.createEmptyState(false);

        assertEquals(0, emptyStateRunOne.getCurrentContent());
        assertEquals(0, emptyStateRunTwo.getCurrentContent());
    }

    @Test
    void createEmptyStateWithSwitchedBottles() {

        //Create two empty states, like in algorithm.
        State emptyStateRunOne = bottleBattle.createEmptyState(true);
        State emptyStateRunTwo = bottleBattle.createEmptyState(false);

        assertEquals(3, emptyStateRunOne.getBottleA().getSize());
        assertEquals(5, emptyStateRunTwo.getBottleA().getSize());
    }


    @Test
    void stepExists() {

        //Create two different states
        State state1 = bottleBattle.createEmptyState(true);
        State state2 = new State(new Bottle(5,1), new Bottle(3,3));

        //Create steplist
        ArrayList<State> stepList = new ArrayList<>();

        //Add one to stepList
        stepList.add(state1);

        //Test
        assertEquals(true, bottleBattle.stepExists(state1, stepList));

        assertEquals(false, bottleBattle.stepExists(state2, stepList));

    }

}