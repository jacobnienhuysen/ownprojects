import bottles.BottleBattle;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {

    BottleBattle bottleBattle = new BottleBattle();

    @Test
    void userInputSmallerThanZero() {

        int input = -1;
        assertEquals(-1, bottleBattle.run(input));
    }

    @Test
    void userInputIsZero() {

        int input = 0;
        assertEquals(0, bottleBattle.run(input));
    }

    @Test
    void userInputIsOne() {

        int input = 1;
        assertEquals(4, bottleBattle.run(input));
    }

    @Test
    void userInputIsFour() {

        int input = 4;
        assertEquals(6, bottleBattle.run(input));
    }

    @Test
    void userInputIsSix() {

        int input = 6;
        assertEquals(3, bottleBattle.run(input));
    }

    @Test
    void userInputIsTooGreat() {

        int input = 9;
        assertEquals(-1, bottleBattle.run(input));

    }


}