public class State {

    private Bottle bottleA;
    private Bottle bottleB;
    private int stepsToGet;

    public State(Bottle bottleA, Bottle bottleB, int stepsToGet){
        this.bottleA = bottleA;
        this.bottleB = bottleB;
        this.stepsToGet = stepsToGet;
    }

    public Bottle getBottleA(){
        return bottleA;
    }

    public Bottle getBottleB(){
        return bottleB;
    }

    public int getBottleAContent(){
        return bottleA.getContent();
    }

    public int getBottleBContent(){
        return bottleB.getContent();
    }

    public int getCurrentContent(){
        return getBottleAContent()+getBottleBContent();
    }

    public int getStepsToGet(){
        return stepsToGet;
    }

    public String toString(){

        return "[" + bottleA.getContent() + ", " + bottleB.getContent() + "], " + stepsToGet + " steg\n";

    }

}
