var step = 1000;

function run(){
	
	//Generate scoreboard
	var data = getScoreboard();
	
	//Convert raw data into scores in ascending orders
	var scores = [];
	
	for(var i=0; i<data.scoreboard.length; i++){
		
		var votes = [];
		
		for(var j=0; j<data.scoreboard[i].votes.length; j++){
			
			var points = data.scoreboard[i].votes[j];
			
			if(points > 0){
				
				var song = {
					draw: j,
					title: data.songList[j].title,
					points: points
				};
				
				votes.push(song);
			}
		
			votes.sort(function(a,b){
				return a.points > b.points;
			});
			
		}
		
		
		var jury = {
			name: data.scoreboard[i].jury,
			votes: votes
		};
		
		scores.push(jury);
	}
	
	
	console.log(scores);
	
	startVoting(scores);
}



function startVoting(scores){
	
	iterateJuries(scores,0);
	
	/*
	//Each jury
	for(var i=0; i<scoreboard.length; i++){
		
		var jury = scoreboard[i];
		var votes = jury.votes;
		
		console.log(votes);
		
		//juryLoop(jury, 0);
		
		/*
		for(var j=0; j<votes.length; j++){
			
			setTimeout(dealScore, 2000, j, votes[j]);
			
		}
		*
		
		//setTimeout(nextJury, 3000);
	}
	
	*/
}

function iterateJuries(scoreboard, index){
	
	nextJury();
	
	if(index < scoreboard.length){
		
		//Write name of jury in info box
		$("#juryname").html(scoreboard[index].name);
		
		//Iterate jury score
		voteLoop(scoreboard[index], 0);
		
		//Call next jury
		setTimeout(function(){
			iterateJuries(scoreboard, ++index);
		}, (step*33));
		
	}
	else{
		$("#juryname").html("Omröstningen är slut.");
	}		
}


function voteLoop(jury, i){
	
	var votes = jury.votes;
	
	setTimeout(function(){
		
		
		dealScore(votes[i]);	
		
		i++;
		
		if(i<votes.length){
			voteLoop(jury,i);
		}
		
		
		
	}, (step*4));
	
}



function dealScore(song){
	
	var draw = song.draw;
	
	var infoText = $("#info");
	infoText.html(song.points + ' poäng går till melodi nummer ' + (draw+1));
	
	var songElement = $("#song" + draw);
	
	var newScore = parseInt(songElement.attr("data-score"),10) + song.points;
	
	var givenScore = $("#given" + draw);
	givenScore.html(song.points);
	
	songElement.attr("data-score", newScore);
	$("#score" + draw).html(newScore);
	songElement.addClass("gotScore");
	
	setTimeout(function(){
		
		animateSort();
	},(step*1.25));
	
}


function animateSort() {

  var promises = [];
  var positions = [];
  var originals = $("#scoreboard").find("li");
  var sorted = originals.toArray().sort(function(a, b) {
	  
	  var score1 = parseInt($(a).attr("data-score"));
	  var score2 = parseInt($(b).attr("data-score"));
	  
	  
    return score2 > score1;
  });

  originals.each(function() {
    //store original positions
    positions.push($(this).position());
  }).each(function(originalIndex) {
    //change items to absolute position
    var $this = $(this);
    var newIndex = sorted.indexOf(this);
    sorted[newIndex] = $this.clone(); //copy the original item before messing with its positioning
    $this.css("position", "absolute").css("top", positions[originalIndex].top + "px").css("left", positions[originalIndex].left + "px");

    //animate to the new position
    var promise = $this.animate({
      top: positions[newIndex].top + "px",
      left: positions[newIndex].left + "px"
    }, 500);
    promises.push(promise);
  });

  //instead of leaving the items out-of-order and positioned, replace them in sorted order
  $.when.apply($, promises).done(function() {
    originals.each(function(index) {
      $(this).replaceWith(sorted[index]);
    });
  });
  
  
}


function nextJury(){
	
	$(".song").each(function(){
		$(this).removeClass("gotScore");
	});
	
	$(".given").each(function(){
		$(this).html("");
	});

	$("#info").html("");

}

$(function() {
  $("#run").click(function() {
	run();
    //animateSort("#scoreboard", "li", "data-score");
  });
});