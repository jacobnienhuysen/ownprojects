//Speed
var step = 500;

//Generate scoreboard
var data = getScoreboard();

//console.log(data);

$( document ).ready(function(){
	
	
	//Print running order
printRunningOrder(data);
	
});


function run(){
	
	//Convert raw data into scores in ascending orders
	var scores = [];
	
	for(var i=0; i<data.scoreboard.length; i++){
		
		var votes = [];
		
		for(var j=0; j<data.scoreboard[i].votes.length; j++){
			
			var points = data.scoreboard[i].votes[j];
			
			if(points > 0){
				
				var song = {
					draw: j,
					title: data.songList[j].title,
					points: points
				};
				
				votes.push(song);
			}
		
			votes.sort(function(a,b){
				return a.points > b.points;
			});
			
		}
		
		
		var jury = {
			name: data.scoreboard[i].jury,
			votes: votes,
			televote: data.scoreboard[i].televote
		};
		
		scores.push(jury);
	}
	
	startVoting(scores);
}



function startVoting(scores){
	
	iterateJuries(scores,0);
	
	/*
	//Each jury
	for(var i=0; i<scoreboard.length; i++){
		
		var jury = scoreboard[i];
		var votes = jury.votes;
		
		console.log(votes);
		
		//juryLoop(jury, 0);
		
		/*
		for(var j=0; j<votes.length; j++){
			
			setTimeout(dealScore, 2000, j, votes[j]);
			
		}
		*
		
		//setTimeout(nextJury, 3000);
	}
	
	*/
}

function iterateJuries(scoreboard, index){
	nextJury();
	
	if(index < scoreboard.length){
		
		//Write name of jury in info box
		$("#juryname").html(scoreboard[index].name);
		
		//Iterate jury score
		voteLoop(scoreboard[index], 0);
		
		//Call next jury
		setTimeout(function(){
			iterateJuries(scoreboard, ++index);
		}, (step*(data.scoreList.length*14)));
		
	}
	else{
		$("#juryname").html("Omröstningen är slut.");
		$("#row1").html('<a href="javascript:printScoreboard()">Öppna poängtavla</a>');
	}		
}


function voteLoop(jury, i){
	
	var votes = jury.votes;
	var televote = jury.televote;
	
	setTimeout(function(){
		
		
		dealScore(votes[i], televote);	
		
		i++;
		
		if(i<votes.length){
			voteLoop(jury,i);
		}
		
		
		
	}, (step*9));
	
}



function dealScore(song, televote){
	
	var draw = song.draw;
	
	var rad1 = $("#row1");
	var rad2 = $("#row2");
	
	rad1.html(song.points + ' poäng');
	
	setTimeout(function(){
		
		rad2.html('Till melodi nummer ' + (draw+1));
	
		var songElement = $("#song" + draw);
		//var songElement = document.getElementById("song" + draw);
		
		var newScore = parseInt(songElement.attr("data-score"),10) + song.points;
		var teleScore = parseInt(songElement.attr("data-tele"), 10);
		
		var givenScore = $("#given" + draw);
		givenScore.html(song.points);
		
		var newScorings = parseInt(songElement.attr("data-scorings"),10) + 1;
		songElement.attr("data-scorings", newScorings);
		
		//Update attributes
		songElement.attr("data-score", newScore);
		if(televote) {
			teleScore += song.points;
			songElement.attr("data-tele", teleScore);
		}
				
		//Update visual scoreboard
		$("#score" + draw).html(newScore);
		songElement.addClass("gotScore");
		songElement.addClass("gotScoreFlash");
		
		var animationDelay = (step/1000)/8 + "s";
		var animationDuration  = (step/1000) * 0.5 + "s";
		
		songElement[0].style.animationDelay = animationDelay;
		songElement[0].style.animationDuration = animationDuration;
		
		setTimeout(function(){
			songElement.removeClass("gotScoreFlash");
		},(step*1.5))
		
		setTimeout(function(){
			animateSort();
		},(step*1.5));
		
		setTimeout(function(){
			rad1.html("");
			rad2.html("");
		},(step*3));
	
	}, step*3);
	
	
	
}


function animateSort() {

	var promises = [];
	var positions = [];
	var originals = $("#scoreboard").find("li");
	var sorted = originals.toArray().sort(function(a, b) {
	  
	var score1 = parseInt($(a).attr("data-score"));
	var score2 = parseInt($(b).attr("data-score"));
	  
	var scorings1 = parseInt($(a).attr("data-scorings"));
	var scorings2 = parseInt($(b).attr("data-scorings"));
	
	var tele1 = parseInt($(a).attr("data-tele"));
	var tele2 = parseInt($(b).attr("data-tele"));
	  
	var televote = data.useTelevote;
	
	if(score2 > score1)  {
		return true;
	}
	else if(score2 == score1){
		if(televote){
			if(tele2 > tele1){
				return true
			}
			else{
				return false;
			}
		}
		else{
			return (scorings2 > scorings1);
		}		
	}
    return false;
	
	//return score2 > score1;
	
  });

  originals.each(function() {
    //store original positions
    positions.push($(this).position());
  }).each(function(originalIndex) {
    //change items to absolute position
    var $this = $(this);
    var newIndex = sorted.indexOf(this);
    sorted[newIndex] = $this.clone(); //copy the original item before messing with its positioning
    $this.css("position", "absolute").css("top", positions[originalIndex].top + "px").css("left", positions[originalIndex].left + "px");

    //animate to the new position
    var promise = $this.animate({
      top: positions[newIndex].top + "px",
      left: positions[newIndex].left + "px"
    }, (step/2));
    promises.push(promise);
  });

  //instead of leaving the items out-of-order and positioned, replace them in sorted order
  $.when.apply($, promises).done(function() {
    originals.each(function(index) {
      $(this).replaceWith(sorted[index]);
    });
  });
  
  
}


function nextJury(){
	
	$(".song").each(function(){
		$(this).removeClass("gotScore");
	});
	
	$(".given").each(function(){
		$(this).html("");
	});

	$("#rad1").html("");
	$("#rad2").html("");

}

$(function() {
  $("#run").click(function() {
	run();
	this.disabled = true;
    //animateSort("#scoreboard", "li", "data-score");
  });
});



function printRunningOrder(data){
	
	var html = "";
	
	//Generate html string
	for(var i=0; i<data.songList.length; i++){		
		html += '<li class="song" data-score="0" data-tele="0" data-scorings="0" id="song' + i + '">';
		html += '<span class="draw">' + (i+1) + '.</span>';
		html += '<span class="title">' + data.songList[i].title + '</span>';
		html += '<span class="given" id="given' + i + '"></span>';
		html += '<span class="score" id="score' + i + '">0</span>';
		html += '</li>';
	}
	
	//Fill table element with html
	$("#scoreboard").html(html);
	
}


function printScoreboard(){
	
	var html = '<!doctype html><html lang="sv"><head><meta charset="UTF-8">';
	
	html += '<link rel="stylesheet" type="text/css" href="styles.css">';
	html += '<link href="https://fonts.googleapis.com/css?family=Days+One|Play&display=swap" rel="stylesheet">';
	
	html += '</head><body><table class="grid">';
	
	//Print header row
	html += '<tr>';
	html += '<th></th>';
	
	for(var j=0; j<data.scoreboard.length; j++){
		html += '<th class="jury">' + data.scoreboard[j].jury + '</th>';
	}
	
	html += '<th>Total</th>';
	html += '<th>Plac.</th>';
	html += '</tr>';
	
	//Print song rows
	for(var s=0; s<data.songList.length; s++){
		
		html += '<tr>';
		html += '<td>' + data.songList[s].title + '</td>';
		
		var total = 0;
		
		//Scores
		for(var i=0; i<data.scoreboard.length; i++){
			
			var points = data.scoreboard[i].votes[s];
			total += points;
			
			if(points === 0){
				html += '<td></td>';
			}
			else if(points === data.scoreList[0] || (data.useTelevote && points/data.televoteValue === data.scoreList[0])){
				html += '<td class="topscore">' + points + '</td>'; 
			}
			else{
				html += '<td>' + points + '</td>';
			}
		}
		
		html += '<td>' + total + '</td>';		
	}
	
	html += '</table></body></html>';
	
	var scoreWindow = window.open("", "Poängtavla");
	
	var doc = scoreWindow.document;
	doc.open("text/html");
	doc.write(html);
	doc.close();
	
}









