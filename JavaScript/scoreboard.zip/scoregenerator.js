var points = [8,6,4,2,1];
var songs = [1,2,3,4,5,6,7,8,9,10];
var weight = [0.094, 0.026, 0.037, 0.125, 0.104, 0.015, 0.067, 0.087, 0.058, 0.387];

function generateWeighedList() {
	var weighedList = [];
	
	//Loop weights
	for(var i=0; i<weight.length; i++){
		var multiples = weight[i] * 100;
	
		for(var j=0; j<multiples; j++){
			weighedList.push(songs[i]);
		}
	}
	
	return weighedList;
}

var rand = function(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
};

var weighed_list = generateWeighedList();


function generateScore(name, isTelevote, teleweight){
	
	var juryScore = [];
	var scores = [];
	
	//Fill scored songs with zeroes
	for(var i=0; i<songs.length; i++){
		scores[i] = 0;
	}
	
	//Fill with scores
	for(var i=0; i<points.length; i++){
		
		var set = false;
		
		while(!set){
			var songNumber = rand(0, weighed_list.length-1);
			var randomDraw = weighed_list[songNumber];
			
			if(scores[randomDraw-1] === 0){
				
				if(isTelevote){
					scores[randomDraw-1] = (points[i]*teleweight);
				}
				else{
					scores[randomDraw-1] = points[i];
				}
				
				//scores[randomDraw-1] = points[i];
				set = true;
			}
		}
		
	}
	
	var result = {
			jury: name,
			score: scores,
			televote: isTelevote
		};
		
	return result;
	
	/*
	while(juryScore.length < points.length){
		
		var songNumber = rand(0, weighed_list.length-1);
		var draw = weighed_list[songNumber]
		
		if(!scoredSongs.includes(draw)){
			scoredSongs.push(draw);
			
			var song = {
				draw: draw,
				points: points[juryScore.length]
			};
			
			juryScore.push(song);
		}	
	}
	
	var result = {
		name: name,
		score: juryScore
	};
	
	return result;*/
	
}

function generateResult(data, televote, teleweight){
	
	var result = [];
	
	//Generate jury scores
	for(var i=0; i<data.juries.length; i++){
		
		var juryScore = generateScore(data.juries[i].name, false, 1);
		result.push(juryScore);
		
	}
	
	//Generate televote?
	if(televote){
		var telescore = generateScore("Tittare", true, teleweight);
		result.push(telescore);
	}
	
	return result;
}