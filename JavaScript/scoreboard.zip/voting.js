function runScripts(televote){

	//JSon data
	var data = contestData;
	
	//Generate scores
	var scoreData = generateResult(data, televote, 11);
	
	//Calculate scores
	var resultList = calcVotes(data, scoreData);
	
	//Rankings
	//var rankingList = calcRankings(scoreData);
	
	//Print song table
	listSongs(resultList);
	
	//Print scoreboard
	printScoreboard(resultList, scoreData, televote);
	
}


function calcVotes(data, scoreData){
	
	var resultList = [];
	
	//Create list of songs from data file
	for(var index=0; index<data.songs.length; index++){
		
		var song = {
			draw: (index+1),
			title: data.songs[index].title,
			score: 0
		};
		
		resultList.push(song);		
	}
	
	//Calculate scores
	for(var i=0; i<scoreData.length; i++){
		
		for(var j=0; j<scoreData[i].score.length; j++){
			
			var points = scoreData[i].score[j];
			var newScore = resultList[j].score += points;
			
		}
		
	}
	
	return resultList;
}


function listSongs(data){
	
	var table = "";
	
	//Generate html string
	for(var i=0; i<data.length; i++){		
		table += '<tr class="song">';
		table += '<td class="draw">' + data[i].draw + '</td>';
		table += '<td class="title">' + data[i].title + '</td>';
		table += '<td class="score">' + data[i].score + '</td>';
		table += '</tr>';
	}
	
	//Fill table element with html
	document.getElementById("songs").innerHTML = table;
	
}


function printScoreboard(finalList, scoreData, televote){
	
	var scoreBoard = [];
	var televoteIndex = 0;
	
	//Build array of songs
	for(var i=0; i<finalList.length; i++){
		
		var song = {
			draw: finalList[i].draw,
			title: finalList[i].title,
			points: [],
			total: finalList[i].score
		};
		
		var temp = [];
		
		for(var x=0; x<scoreData.length; x++){
		
			var points = scoreData[x].score[i];
			temp.push(points);
			
		}
		
		song.points = temp;
		
		scoreBoard.push(song);
	}
	
	//generate html
	var table = "";
	
	//Table headers
	table += '<tr class="headers">';
	table += '<th></th>';
	table += '<th>Titel</th>';
	
	for(var i=0; i<scoreData.length; i++){
		
		var shortName = 
		
		table += '<th class="jury">' + scoreData[i].jury + '</th>';
		
		
		if(scoreData[i].televote){
			televoteIndex = i;
		}
	}
	
	table += '<th class="total">Total</th>';
	table += '<th class="total">Plac.</th>';
	
	
	//Generate rankings
	var rankings = calcRankings(scoreBoard, televote);
	
	//Scoreboard
	for(var i=0; i<scoreBoard.length; i++){		
		table += '<tr class="song">';
		table += '<td class="draw">' + scoreBoard[i].draw + '</td>';
		table += '<td class="title">' + scoreBoard[i].title + '</td>';
		
		var points = scoreBoard[i].points;
		var total = 0;
		
		for(var j=0; j<points.length; j++){
			
			var value = points[j];
			
			if(value === 0){
				value = " ";
			}
			
			if(j === televoteIndex && televote){
				table += '<td class="point televote">' + value + '</td>';
			}
			else{
				table += '<td class="point">' + value + '</td>';
			}
			
			total += points[j];
		}
		
		table += '<td class="score">' + total + '</td>';
		
		var rank = rankings.indexOf(rankings.find(function(element){
			return isSong(element,scoreBoard[i].draw);
		}));
		
		table += '<td class="rank">' + (rank+1) + '</td>';
		
		table += '</tr>';
	}
	
	document.getElementById("scores").innerHTML = table;

}


function calcRankings(scoreData, televote, televoteIndex){
	
	var rankings = [];
	
	for(var i=0; i<scoreData.length; i++){
		
		var song = {
			draw: i+1,
			total: 0,
			numOfScorings: 0,
			allPoints: []
		};
		
		var total = 0;
		
		for(var j=0; j<scoreData[i].points.length; j++){
			
			var temp = scoreData[i].points[j];
			
			if(song.allPoints[temp]){
				song.allPoints[temp]++;
			}
			else{
				song.allPoints[temp] = 1;
			}
			
			total += temp;
			
			if(temp > 0){
				song.numOfScorings++;
			}
			
		}
		song.total = total;
		song.allPoints.reverse();
		rankings.push(song);
	}
	
	//Sort rankinglist.
	//Televote ranks higher if equal score.
	//Next, scores from more juries ranks higher if equal amount of points. If still equal, earlier draw ranks higher.
	//TODO: Rank by number of 12s, 10s etc before looking at draw.
	rankings.sort(function(a,b){
		
		if(b.total > a.total){
			return true;
		}
		else if(b.total === a.total){
			if(b.numOfScorings > a.numOfScorings){
				return true;
			}
			else if(b.numOfScorings === a.numOfScorings){
				return a.draw > b.draw;
			}
			/*
			else if(b.numOfScorings === a.numOfScorings){
				return hasMostPoints(a,b,0);
			}*/
		}
				
		return false;	
	});

	return rankings;	
}


function isSong(element, draw) {
  return element.draw === draw;
}


function hasMostPoints(a,b,level){
	
	if(level < a.allPoints.length){
		if(a.allPoints[level] === b.allPoints[level]){
			hasMostPoints(a,b,level--);
		}
		else if(a.allPoints[level] < b.allPoints[level]){
			return true;
		}
		else{
			return false;
		}
	}	
	return false;	
}


/*The OLD Json way */

function calcVotesFromJson(){
	
	var scoreList = new Array();
	
	for(var index=0; index<data.songs.length; index++){
		
		var song = {
			draw: (index+1),
			score: 0
		};
		
		scoreList.push(song);		
	}
	
	//First vote
	var list = data.first;
	
	for(var i=0; i<list.length; i++){
		
		var votes = list[i].votes;
		
		for(var j=0; j<votes.length; j++){
			
			var song = votes[j];
			var currentScore = scoreList[song].score;
			
			var newScore = currentScore + 1;
			scoreList[song].score = newScore;
			
		}
		
	}
	
	//Sort by score
	scoreList.sort(function(a, b){
		return b.score > a.score;
	});

	//Put 5 best in new list and sort by draw
	var finalList = scoreList.slice(0, 5);
	var finalList = scoreList.slice(0, 5);
	
	
	//Sort by draw and set score to 0
	finalList.sort(function(a, b){
		a.score = 0;
		b.score = 0;
		return a.draw > b.draw;
	});
	
	//Second vote
	var list = data.second;
	
	for(var i=0; i<list.length; i++){
		
		var votes = list[i].votes;
		
		for(var j=0; j<finalList.length; j++){
			
			var song = finalList[j];
			var currentScore = song.score;
			
			var newScore = currentScore + votes[j];
			finalList[j].score = newScore;
			
		}
		
	}

	list = data.songs;

	for(var i=0; i<list.length; i++){
		
		var finalScore = getScoreByDraw(finalList, (i+1));
		list[i].points = finalScore;
	}
	
	printScoreboard(finalList);
	
	return list;
}

function getScoreByDraw(list, draw){
	
	for(var i=0; i<list.length; i++){
		if(list[i].draw == draw){
			return list[i].score;
		}
	}
	
	return 0;
}



/* the json way */

function printScoreboardFromJson(finalList){
	
	var scoreBoard = new Array();
	var scoreData = data.second;
	
	for(var i=0; i<finalList.length; i++){
		
		var song = {
			draw: finalList[i].draw,
			title: data.songs[(finalList[i].draw-1)].title,
			points: []
		};
		
		for(var j=0; j<scoreData.length; j++){
			
			song.points.push(scoreData[j].votes[i]);
			
		}
		scoreBoard.push(song);
	}
	
	var table = "";
	
	for(var i=0; i<scoreBoard.length; i++){		
		table += '<tr class="song">';
		table += '<td class="draw">' + scoreBoard[i].draw + '</td>';
		table += '<td class="title">' + scoreBoard[i].title + '</td>';
		
		var points = scoreBoard[i].points;
		var total = 0;
		
		for(var j=0; j<points.length; j++){
			table += '<td class="point">' + points[j] + '</td>';
			total += points[j];
		}
		
		table += '<td class="score">' + total + '</td>';
		table += '</tr>';
	}
	
	document.getElementById("scores").innerHTML = table;
}